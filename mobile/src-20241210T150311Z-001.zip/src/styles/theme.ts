import { colors } from "./colors"
import { fontFamily } from "./font-family"

export { colors, fontFamily }
