export const fontFamily = {
  bold: "Rubik_700Bold",
  medium: "Rubik_500Medium",
  regular: "Rubik_400Regular",
  semiBold: "Rubik_600SemiBold",
}
